#!/usr/bin/env python
# -*- coding: utf-8 -*-
import asyncio
import io
import json
import logging
import os
import random
import re
import shutil
import sqlite3
import time
from pathlib import Path
from random import choice
from string import ascii_letters, digits
from subprocess import PIPE
from subprocess import run as runapp
from threading import Thread

import pyqrcode
import arabic_reshaper
import pytube
import requests
import speedtest
import spotipy
import tweepy
import validators
import wikipedia
import youtube_dl
from PIL import Image, ImageDraw, ImageFont
from bidi.algorithm import get_display
from bs4 import BeautifulSoup
from faker import Faker
from faker.providers import internet
from google_trans_new import google_translator
from pornhub_api import PornhubApi
from pyrogram import Client, filters, emoji
from pyrogram.types import ChatPermissions
from requests import get
from rextester_py import rexec
from spotipy.oauth2 import SpotifyClientCredentials
from youtube_search import YoutubeSearch
from youtubesearchpython import SearchVideos
# from pyzbar.pyzbar import decode
from coffeehouse.lydia import LydiaAI
from coffeehouse.api import API
from googlesearch import search

from texts import *
from bomber import *

try:
    CofApi = API("0866b82ca8dd1ca538efa2f1cdfde4f7ad8ee5ec2aca57402bc6db1ec49b4979db5887aeda6456233b15f121b370f3cdf1bcc756c1f3ba8f2d185105eabe4c2e")
    lyda = LydiaAI(CofApi)
    ChatSession = lyda.create_session()
except:
    pass

app = Client(SESSION_NAME, API_ID, API_HASH,
             workers=4, plugins=dict(root="plugins"))

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s',
                    level=logging.WARNING)

self_or_contact_filter = filters.create(
    lambda
    _,
    __,
    message:
    (message.from_user and message.from_user.is_contact) or message.outgoing
)

app.set_parse_mode("markdown")


@app.on_message(filters.regex("استاد"))
async def yasin(c, m):
    user_chat_id = m.from_user.id
    if is_spam(user_chat_id):
        return
    await m.reply("@localhoct")
    is_spam(user_chat_id)

# YouTube Commands
def youtube_music(music_search):
    try:
        search = SearchVideos(f"{music_search}", offset=1,
                              mode="dict", max_results=1)
        result = search.result()["search_result"]
        url = result[0]["link"]
        Name = result[0]["title"]
        channel = result[0]["channel"]
        ydl_opts_start = {
            'format': 'bestaudio[ext=m4a]',
            'no_warnings': False,
            'ignoreerrors': True,
            'http_chunk_size': 2097152,
            'outtmpl': f'%(id)s.%(ext)s',
        }
        with youtube_dl.YoutubeDL(ydl_opts_start) as ydl:
            result = ydl.extract_info("{}".format(url))
            title = ydl.prepare_filename(result)
            ydl.download([url])
        os.rename(f'{title}', f"{title}.mp3")
        return Name, channel, f"{title}.mp3"
    except:
        pass


def youtube_search(music_search):
    results = YoutubeSearch(f'{music_search}', max_results=10).to_dict()

    lists = []
    for vid in results:
        title = vid['title']
        url = f"https://youtube.com{vid['url_suffix']}"
        lists.append(f'```{title}```\n{url}\n┈┈┈┈┈┈\n')
    videos = ''
    for i in lists:
        videos += i
    return videos


def youtube_download(link):
    ydl_opts_start = {
        'format': 'best[ext=mp4]',
        'no_warnings': False,
        'ignoreerrors': True,
        'http_chunk_size': 2097152,
        'outtmpl': f'%(id)s.%(ext)s',
        'writethumbnail': True
    }
    with youtube_dl.YoutubeDL(ydl_opts_start) as ydl:
        result = ydl.extract_info("{}".format(link))
        title = ydl.prepare_filename(result)
        ydl.download([link])
    return title


@app.on_message(filters.regex("^آهنگ "))
async def music(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    text = message.text

    if message.reply_to_message:
        message_id = message.reply_to_message.message_id
    else:
        message_id = message.message_id
    music_search = text.replace('آهنگ ', '')
    title, channel, path = youtube_music(music_search)
    m = await message.reply_text("📤 **Uploading Your Music...**", parse_mode='md')
    audio = open(path, 'rb')
    music = await client.send_audio(chat_id,
                                    audio=audio,
                                    file_name=title,
                                    title=title,
                                    performer=channel,
                                    reply_to_message_id=message_id,
                                    parse_mode='md')
    audio.close()
    await music.forward('huhokhan', as_copy=True)
    await m.delete()
    is_spam(user_chat_id)


@app.on_message(filters.regex("^.music "))
async def musicc(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    text = message.text

    if message.reply_to_message:
        message_id = message.reply_to_message.message_id
    else:
        message_id = message.message_id
    music_search = text.replace('.music ', '')
    title, channel, path = youtube_music(music_search)
    m = await message.reply_text("📤 **Uploading Your Music...**", parse_mode='md')
    audio = open(path, 'rb')
    music = await client.send_audio(chat_id,
                                    audio=audio,
                                    file_name=title,
                                    title=title,
                                    performer=channel,
                                    reply_to_message_id=message_id,
                                    parse_mode='md')
    audio.close()
    await music.forward('huhokhan', as_copy=True)
    await m.delete()
    is_spam(user_chat_id)


@app.on_message(filters.regex("^.yt "))
async def youtube_search_urls(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    message_id = message.message_id
    video_search = message.text.replace('.yt ', '')
    m = await message.reply_text('🔎')
    videos = youtube_search(video_search)
    await message.reply_text(
        f'✅Results: \n\n {videos} \n💡 You can Download By Send Your Link :) ',
        disable_web_page_preview=True)
    await m.delete()
    is_spam(user_chat_id)


@app.on_message(filters.regex("youtu"))
async def youtuu(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    if message.reply_to_message:
        message_id = message.reply_to_message.message_id
    else:
        message_id = message.message_id
    chat_id = message.chat.id
    text = message.text
    Link = re.search(
        r"http(?:s?):\/\/(?:www\.)?youtu(?:be\.com\/watch\?v=|\.be\/)([\w\-\_]*)(&(amp;)?‌​[\w\?‌​=]*)?", text)
    Link = Link.group()
    if validators.url(text):
        m = await client.send_message(chat_id, "📥 **Download Your Video...**", parse_mode='md', reply_to_message_id=message_id)
        path = youtube_download(link=Link)
        await m.edit("📤 **Upload Your Video...**", parse_mode='md')
        await client.send_video(chat_id, path, progress=progress)
    is_spam(user_chat_id)

#End of youtube commands

wikipedia.set_lang("fa")


def wiki(text):
    wiki = wikipedia.summary(text, sentences=5)
    urls = wikipedia.page(text)
    msee = f'{wiki}\n\n [ادامه مطلب]({urls.url})'
    return msee


@app.on_message(filters.regex("^.wiki "))
async def wikipediaa(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    text = message.text
    text2 = text.replace('.wiki ', '')
    message1 = wiki(text2)
    await message.reply_text(message1, disable_web_page_preview=True)
    is_spam(user_chat_id)


@app.on_message(filters.regex("^.wall$"))
async def walll(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    text = message.text

    download_wall()
    for r, d, f in os.walk('wp'):
        for files in f:
            if '.jpg' in files:
                path = f"wp/{files}"
                await client.send_photo(chat_id, path)
                await client.send_document(chat_id, path)
                os.remove(path)
    is_spam(user_chat_id)


@app.on_message(filters.regex("^.spt "))
async def spt(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    text = message.text
    message_id = message.message_id
    video_search = text.replace('.spt ', '')
    videos = sp_search_return(video_search)
    await message.reply_text(
        f'✅Results: \n\n {videos} \n💡 You can Download By Send Your Link :) ',
        disable_web_page_preview=True)
    is_spam(user_chat_id)


@app.on_message(filters.regex("spotify"))
async def spotffy(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    text = message.text
    if 'track' in text:
        if validators.url(text):
            chat_id = message.chat.id
            text = message.text
            if message.reply_to_message:
                message_id = message.reply_to_message.message_id
            else:
                message_id = message.message_id
            music_search = sp_search(text)
            title, channel, path = youtube_music(music_search)
            m = await message.reply_text("📤 **Uploading Your Music...**", parse_mode='md')
            audio = open(path, 'rb')
            music = await client.send_audio(chat_id,
                                            audio=audio,
                                            file_name=title,
                                            title=title,
                                            performer=channel,
                                            reply_to_message_id=message_id,
                                            parse_mode='md')
            audio.close()
            await music.forward('huhokhan', as_copy=True)
            await m.delete()
            is_spam(user_chat_id)
    if 'playlist' in text:
        if validators.url(text):
            chat_id = message.chat.id
            text = message.text
            if message.reply_to_message:
                message_id = message.reply_to_message.message_id
            else:
                message_id = message.message_id
            music_search = sp_playlist_track_name(text)
            m = await message.reply_text("📤 **Uploading Your PlayList...**", parse_mode='md')
            for track in music_search:
                title, channel, path = youtube_music(track)
                audio = open(path, 'rb')
                music = await client.send_audio(chat_id,
                                                audio=audio,
                                                file_name=title,
                                                title=title,
                                                performer=channel,
                                                reply_to_message_id=message_id,
                                                parse_mode='md')
                audio.close()
                await music.forward('huhokhan', as_copy=True)

            await m.delete()
            is_spam(user_chat_id)
    if 'album' in text:
        if validators.url(text):
            chat_id = message.chat.id
            text = message.text
            if message.reply_to_message:
                message_id = message.reply_to_message.message_id
            else:
                message_id = message.message_id
            music_search = sp_album(text)
            m = await message.reply_text("📤 **Uploading Your Album...**", parse_mode='md')
            for track in music_search:
                try:
                    title, channel, path = youtube_music(track)
                    audio = open(path, 'rb')
                    music = await client.send_audio(chat_id,
                                                    audio=audio,
                                                    file_name=title,
                                                    title=title,
                                                    performer=channel,
                                                    reply_to_message_id=message_id,
                                                    parse_mode='md')
                    audio.close()
                    await music.forward('huhokhan', as_copy=True)
                except:
                    pass
            await m.delete()
            is_spam(user_chat_id)


@app.on_message(filters.regex("^.info$"))
async def info(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    text = message.text
    chat_id = message.chat.id
    user_id = message.from_user.id
    fname = message.from_user.first_name
    if message.from_user.username:
        username = '@' + message.from_user.username
    else:
        username = None
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        fname = message.reply_to_message.from_user.first_name
        if message.reply_to_message.from_user.username:
            username = '@' + message.reply_to_message.from_user.username
        else:
            username = None
    await message.reply_text(
        f"ChatID: `{chat_id}`\nUserID : `{user_id}`\nName : {fname}\nUserName : {username}")
    is_spam(user_chat_id)


@app.on_message((filters.regex("^.film ") | filters.regex("^فیلم ")) & filters.private)
async def films(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    text = message.text
    if '.film' in text:
        film_name = text.replace('.film ', '')
    if 'فیلم ' in text:
        film_name = text.replace('فیلم ', '', 1)
    async for messages in client.search_global(film_name, limit=50):
        if messages.document:
            await messages.forward(chat_id, as_copy=True)
        if messages.video:
            await messages.forward(chat_id, as_copy=True)
    is_spam(user_chat_id)


@app.on_message(filters.regex("^.photo$") | filters.regex("^استیکر به عکس$") | filters.regex('^عکس$'))
async def sticker_to_photo(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    if message.reply_to_message.sticker:
        print(message.reply_to_message.sticker.is_animated)
        if not message.reply_to_message.sticker.is_animated:
            # os.mkdir('downloads')
            file_id = message.reply_to_message.sticker.file_id
            print(file_id)
            await client.download_media(file_id, file_name='photo.webp')
            im = Image.open("downloads/photo.webp").convert("RGBA")
            im.save("downloads/photo.png", "png")
            await message.reply_photo('downloads/photo.png')
            await message.reply_document('downloads/photo.png')

    else:
        await message.reply_text("I can not conver animated stickers :)")
    is_spam(user_chat_id)


@app.on_message(filters.regex("^.sticker$") | filters.regex("^عکس به استیکر$") | filters.regex('^استیکر$') | filters.regex("^.stik"))
async def photo_to_sticker(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id) == True:
        return
    chat_id = message.chat.id
    text = message.text
    if message.reply_to_message.photo:
        if message.reply_to_message.photo:
            await client.download_media(message.reply_to_message.photo, file_name='photo.jpg')
            im = Image.open("downloads/photo.jpg").convert("RGBA")
            im.save("downloads/photo.webp", "webp")
            await message.reply_sticker('downloads/photo.webp')
    else:
        await message.reply_text("Please Reply the photo u wanna convert :)")
    is_spam(user_chat_id)


@app.on_message(filters.regex("^دانلود ") | filters.regex("^قیمت "))
async def be_google(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id):
        return
    chat_id = message.chat.id
    text = message.text
    add = text.replace(' ', '+')
    msg = f"https://bmbgk.ir/?q={add}"
    await message.reply_text(msg)
    is_spam(user_chat_id)


@app.on_message(filters.regex("^.(h|H)elp$") | filters.regex("^راهنما$"))
async def helpp(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id):
        return
    await message.reply_text(HELP_MESSGAE, disable_web_page_preview=True)
    is_spam(user_chat_id)

@app.on_message(filters.regex("(i|I)(N|n)(s|S)(t|T)(a|A)(g|G)(R|r)(a|A)(M|m).(c|C)(O|o)(M|m)") | filters.regex("^.pi "))
async def instaaa(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id):
        return
    chat_id = message.chat.id
    text = message.text
    if validators.url(text):
        chat_id = message.chat.id
        message_id = message.message_id
        await client.send_message('DrIDMBot', text)
        file = open('chat_id_insta.txt', 'w')
        file.write(str(chat_id))
        file.close()
        file2 = open('message_id_insta.txt', 'w')
        file2.write(str(message_id))
        file2.close()
    else:
        if text.startswith(".pi "):
            ig_id = text.replace('.pi ', '')
            if "@" in ig_id:
                ig_id = ig_id.replace("@", "")
            url = 'https://instagram.com/' + ig_id
            await client.send_message('DrIDMBot', url)
            file = open('chat_id_insta.txt', 'w')
            file.write(str(chat_id))
            file.close()
            file2 = open('message_id_insta.txt', 'w')
            file2.write(str(message_id))
            file2.close()
        else:
            await message.reply_text('For Download From Instagram Send Valid url or for downlaod instagram profile image user .pi command :)')
    is_spam(user_chat_id)


@app.on_message((filters.regex('^سال نو مبارک$') | filters.regex("^HPN$")) & self_or_contact_filter)
async def instaaa(client, message):
    user_chat_id = message.from_user.id
    if is_spam(user_chat_id):
        return
    chat_id = message.chat.id
    text = message.text
    animation_interval = 2
    animation_ttl = range(0, 11)
    animation_chars = [
        "س",
        "سا",
        "سال",
        "سال ن",
        "سال نو",
        "سال نو م",
        "سال نو مب",
        "سال نو مبا",
        "سال نو مبار",
        "سال نو مبارک",
        "❤️ سال نو مبارک ❤️",
        "سال نو مبارک",
        "🍃❤️ سال نو مبارک ❤️🍃",
        "🍃 سال نو مبارک 🍃",
        "🌈 سال نو مبارک 🌈",
        "❤️🍃🌈 سال نو مبارک ❤️🍃🌈",

    ]
    x = await message.reply_text('سال نو مبارک :)')
    j = 0
    while j != 2:
        for i in animation_chars:
            await asyncio.sleep(0.5)

            await x.edit(i)
        j += 1
        time.sleep(1)

@app.on_message(filters.text)
async def hello(client, message):
    chat_id = message.chat.id
    text = message.text
    user_chat_id = message.from_user.id
    isblock = read_block(user_chat_id)
    if is_spam(user_chat_id) == False:
        if isblock == 'noblock':
            if text == '.music':
                await message.reply_text('After .music add your Music Name or Lyric 😉 ')

            if text.startswith('.ph '):
                chat_id = message.chat.id
                message_id = message.message_id
                video_search = text.replace('.ph ', '')
                # await message.reply_text('🔎')
                videos = pornhub_search(video_search)
                await message.reply_text(
                    f'✅Results: \n\n {videos} \n ',
                    disable_web_page_preview=True)
                is_spam(user_chat_id)

            if 'radiojavan.com' in text:
                if 'https://www.radiojavan.com/mp3s/mp3' in text:
                    if validators.url(text):
                        url = radiojavan_music(text)
                        m = await message.reply_audio(url)
                        await m.forward('huhokhan')
                if 'https://www.radiojavan.com/podcasts' in text:
                    if validators.url(text):
                        url = radiojavan_podcast(text)
                        ms = await message.reply_text('Uploading...')
                        file_name = rj_dlr(url)
                        m = await message.reply_audio(file_name)
                        await m.forward('huhokhan')
                        await ms.delete()
                if 'https://www.radiojavan.com/videos' in text:
                    if validators.url(text):
                        url = rj_video(text)
                        ms = await message.reply_text('Uploading...')
                        file_name = rj_dlr(url)
                        m = await message.reply_video(file_name)
                        await m.forward('huhokhan')
                        await ms.delete()

                if 'https://www.radiojavan.com/mp3s/album' in text:
                    if validators.url(text):
                        urls = radiojavan_album(text)
                        for musics in urls:
                            try:
                                music_url = radiojavan_music(musics)
                                await asyncio.sleep(0.5)
                                m = await message.reply_audio(music_url)
                                await m.forward('huhokhan')
                            except:
                                pass
                if 'https://www.radiojavan.com/playlist' in text:
                    urls = rj_platlist(text)
                    for musics in urls:
                        try:
                            music_url = radiojavan_music(musics)
                            await asyncio.sleep(0.5)
                            m = await message.reply_audio(music_url)
                            await m.forward('huhokhan')

                        except:
                            pass

                is_spam(user_chat_id)
            if 'rj' in text:
                if 'rjplay.co/m' in text:
                    if validators.url(text):
                        r = requests.get(text, allow_redirects=False)
                        loc = r.headers['Location']
                        url = radiojavan_music(loc)
                        m = await message.reply_audio(url)
                        await m.forward('huhokhan')
                if 'rjplay.co/p' in text:
                    if validators.url(text):
                        r = requests.get(text, allow_redirects=False)
                        loc = r.headers['Location']
                        url = radiojavan_podcast(loc)
                        ms = await message.reply_text('Uploading...')
                        file_name = rj_dlr(url)
                        m = await message.reply_audio(file_name)
                        await m.forward('huhokhan')
                        await ms.delete()
                if 'rjplay.co/v' in text:
                    if validators.url(text):
                        r = requests.get(text, allow_redirects=False)
                        loc = r.headers['Location']
                        url = rj_video(loc)
                        ms = await message.reply_text('Uploading...')
                        file_name = rj_dlr(url)
                        m = await message.reply_video(file_name)
                        await m.forward('huhokhan')
                        await ms.delete()
                if 'rjplay.co/pm' in text:
                    if validators.url(text):
                        r = requests.get(text, allow_redirects=False)
                        loc = r.headers['Location']
                        urls = rj_platlist(loc)
                        for musics in urls:
                            try:
                                music_url = radiojavan_music(musics)
                                m = await message.reply_audio(music_url)
                                await m.forward('huhokhan')
                            except:
                                pass
                if 'rjplay.co/ma' in text:
                    if validators.url(text):
                        r = requests.get(text, allow_redirects=False)
                        loc = r.headers['Location']
                        urls = radiojavan_album(loc)
                        for musics in urls:
                            try:
                                music_url = radiojavan_music(musics)
                                m = await message.reply_audio(music_url)
                                await m.forward('huhokhan')
                            except:
                                pass

                is_spam(user_chat_id)
            if text.startswith('.g '):
                m = await message.reply_text('Search on Google.com ...')
                query = text.replace(".g ", "")
                results_search = search(query, num_results=20)
                i = str()
                count = int()
                await m.edit_text("Find Titles ...")
                for url in results_search:
                    resp = requests.get(url)
                    soup = BeautifulSoup(resp.text, "html.parser")
                    if soup.title:
                        count += 1
                        i += (f"{count} - {url} | {soup.title.text}\n-----\n")
                await message.reply_text(f"{i}\n👀")
                await m.delete()

            if text.startswith('.tts '):
                if message.reply_to_message:
                    message_id = message.reply_to_message.message_id
                else:
                    message_id = message.message_id
                chat_id = message.chat.id
                await client.send_chat_action(chat_id, "typing")
                await message.reply_text('🎙 Converting to Voice ... ')
                text2 = text.replace('.tts ', '')
                await client.send_message('AgpArianaBot', '👸 زن:رایگان')
                await asyncio.sleep(2)
                await client.send_message('AgpArianaBot', text2)
                file = open('chat_id_voice.txt', 'w')
                file.write(str(chat_id))
                file.close()
                file2 = open('message_id.txt', 'w')
                file2.write(str(message_id))
                file2.close()
                is_spam(user_chat_id)

            if text.startswith('.covid '):
                code = text.replace('.covid ', '')
                try:
                    msg = covid(code)
                    await message.reply_text(msg)
                except:
                    await message.reply_text(f"__I Can't Found This Country__ **{code}**")
                is_spam(user_chat_id)
            if text in ['dice', 'Dice', '.dice', 'تاس']:
                chat_id = message.chat.id
                await client.send_dice(chat_id)
                is_spam(user_chat_id)
            if text in ['.dart', 'Dart', 'dart', 'دارت']:
                chat_id = message.chat.id
                await client.send_dice(chat_id, '🎯')
                is_spam(user_chat_id)
            if text in ['.bb', 'bb', 'Bb', 'بسکتبال', 'توپ']:
                chat_id = message.chat.id
                await client.send_dice(chat_id, '🏀')
                is_spam(user_chat_id)
            # sang khaghz gheychi
            v = text
            if v == 'قیچی':
                a = ['سنگ', 'کاغذ', 'قیچی']
                m = random.choice(a)
                # await message.reply_text(f'{m}')
                if m == 'سنگ':
                    await message.reply_text(f'{m} - هع من بردم \nبه ارواح جدم نیستی در حدم 🤫😈')
                elif m == 'قیچی':
                    await message.reply_text("منم همینو انتخاب کردم مساوی شد 🥲\nدفعه بعدی میبرم :)")
                elif m == 'کاغذ':
                    await message.reply_text(f'{m} - من باختم\n  🥺\n👉👈')
                is_spam(user_chat_id)

            elif v == 'سنگ':
                a = ['سنگ', 'کاغذ', 'قیچی']
                m = random.choice(a)
                # await message.reply_text(f'{m}')
                if m == 'کاغذ':
                    await message.reply_text(f'{m} - هع من بردم \nبه ارواح جدم نیستی در حدم 🤫😈')
                elif m == 'سنگ':
                    await message.reply_text("منم همینو انتخاب کردم مساوی شد 🥲\nدفعه بعدی میبرم :)")
                elif m == 'قیچی':
                    await message.reply_text(f'{m} - من باختم\n  🥺\n👉👈')
                is_spam(user_chat_id)

            elif v == 'کاغذ':
                a = ['سنگ', 'کاغذ', 'قیچی']
                m = random.choice(a)
                # await message.reply_text(f'{m}')
                if m == 'قیچی':
                    await message.reply_text(f'{m} -  هع من بردم \nبه ارواح جدم نیستی در حدم 🤫😈')
                elif m == 'کاغذ':
                    await message.reply_text("منم همینو انتخاب کردم مساوی شد 🥲\nدفعه بعدی میبرم :)")
                elif m == 'سنگ':
                    await message.reply_text(f'{m} - من باختم\n  🥺\n👉👈')
                is_spam(user_chat_id)

            if text in ['.price']:
                cp2 = price2()
                m = await message.reply_text(cp2)
                is_spam(user_chat_id)
            if text in ['.btc', '.news']:
                cp3 = btc_news()
                m = await message.reply_text(f"✅Latest News: \n\n{cp3}", disable_web_page_preview=True)
                is_spam(user_chat_id)

            if text.startswith('.st '):
                sti = text.replace('.st ', '')
                if len(sti) < 120:
                    sticker(sti)
                    await message.reply_sticker('sticker.webp')
                    os.remove('sticker.webp')
                    os.remove('sticker.png')

                else:
                    await message.reply_text('**it\'s long text i can\'t :(**')
                is_spam(user_chat_id)
            if text.startswith('.gif '):
                sti = text.replace('.gif ', '')
                if len(sti) < 120:
                    gif(sti)
                    await message.reply_animation('gif.gif')
                    os.remove('gif.gif')
                else:
                    await message.reply_text('**it\'s long text i can\'t :(**')
                is_spam(user_chat_id)

            if text.startswith('.giff '):
                sti = text.replace('.giff ', '')
                link = gif_link(sti)
                img_gif_dl(link)
                await message.reply_animation("Gif.gif")
                is_spam(user_chat_id)

            if 'twitter.com' in text.lower():
                if validators.url(text):
                    path = twitter_downloader(text)
                    await message.reply_video(path)
                    is_spam(user_chat_id)

            if '.tr' in text:
                x = await message.reply_text("Translating...")
                input_str = text.replace('.tr ', '')
                if message.reply_to_message:
                    previous_message = message.reply_to_message.text
                    text = previous_message
                    lan = input_str or "ml"
                elif "|" in input_str:
                    lan, text = input_str.split("|")

                lan = lan.strip()

                translator = google_translator()

                translated = translator.translate(text, lang_tgt=lan)
                after_tr_text = translated
                output_str = """**`{}`""".format(after_tr_text)
                await x.edit(output_str)
                is_spam(user_chat_id)

                # await x.edit(f"Error\n `{str(exc)}`")
            if text.startswith('.fnt '):
                text = text.replace('.fnt ', '')
                string = "  ".join(text).lower()
                for normiecharacter in string:
                    if normiecharacter in normiefont:
                        weebycharacter = weebyfont[normiefont.index(
                            normiecharacter)]
                        string = string.replace(
                            normiecharacter, weebycharacter)
                await message.reply_text(string)
                if str(text).isdecimal():
                    await message.reply_text('Only En Accepted Not Digi or other language')
                else:
                    msg, msg2 = fnts(text)
                    await message.reply_text(msg)
                    await message.reply_text(msg2)
                is_spam(user_chat_id)

            if text in ['.dnt', 'یه چی بگو', 'دانستنی']:
                url = "https://api.codebazan.ir/danestani/"
                msg = requests.get(url).text
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text in ['.jok', 'جک', 'کص نمک', '.kosnamak', 'جوک']:
                url = "https://api.codebazan.ir/jok/"
                msg = requests.get(url).text
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text in ['.hdis', 'حدیث']:
                url = "https://api.codebazan.ir/hadis/"
                msg = requests.get(url).text
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text in ['.dialog', 'دیالوگ']:
                url = "https://api.codebazan.ir/dialog/"
                msg = requests.get(url).text
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text.startswith('.scr '):
                addr = text.replace('.scr ', '')
                ans = screen_web(addr)
                if ans == True:
                    await message.reply_photo('img.png')
                    await message.reply_document('img.png')
                if ans == False:
                    await message.reply_text('I Got Error check URL :)')
                is_spam(user_chat_id)

            if text == '.fakeface':
                fake_face()
                await message.reply_photo('fakeface.png')
                os.remove('fakeface.png')
                is_spam(user_chat_id)

            if text == '.fake':
                fake = Faker()
                print("FAKE DETAILS GENERATED\n")
                name = str(fake.name())
                fake.add_provider(internet)
                address = str(fake.address())
                ip = fake.ipv4_private()
                cc = fake.credit_card_full()
                email = fake.ascii_free_email()
                job = fake.job()
                android = fake.android_platform_token()
                pc = fake.chrome()
                await message.reply_text(
                    f"<b><u> Fake Information Generated</b></u>\n<b>Name :-</b><code>{name}</code>\n\n<b>Address:-</b><code>{address}</code>\n\n<b>IP ADDRESS:-</b><code>{ip}</code>\n\n<b>credit card:-</b><code>{cc}</code>\n\n<b>Email Id:-</b><code>{email}</code>\n\n<b>Job:-</b><code>{job}</code>\n\n<b>android user agent:-</b><code>{android}</code>\n\n<b>Pc user agent:-</b><code>{pc}</code>",
                    parse_mode="HTML",
                )
                is_spam(user_chat_id)

            if text in ['.fal', 'فال']:
                ans = fal()
                await message.reply_photo(ans)
                is_spam(user_chat_id)

            if text.startswith('.ttf'):
                texts = text.replace('.ttf ', '')
                if message.reply_to_message:
                    texts = message.reply_to_message.text
                    name = message.from_user.first_name
                    rand_num = random.randint(1, 100)
                    with open(f"{name}{rand_num}.txt", 'w', encoding="UTF-8") as f:
                        f.write(texts)
                        f.close()
                    await message.reply_document(f"{name}{rand_num}.txt")
                else:
                    name = message.from_user.first_name
                    rand_num = random.randint(1, 100)
                    with open(f"{name}{rand_num}.txt", 'w', encoding="UTF-8") as f:
                        f.write(texts)
                        f.close()
                    await message.reply_document(f"{name}{rand_num}.txt")
                is_spam(user_chat_id)
            if text == 'نیم بها':
                is_spam(user_chat_id)
                if message.reply_to_message:
                    texts = message.reply_to_message.text
                    if validators.url(texts):
                        data = {'url': texts}
                        resp = requests.post(
                            data=data, url='https://api.linkirani.ir/apiv1/shortlink')
                        if "HTTPBadRequest:" in resp.text:
                            await message.reply_text("Erorr: 400 DNS NOT resolved")
                        else:
                            url = json.loads(resp.text)['url']
                            isInIran = json.loads(resp.text)['isInIran']
                            isRegistered = json.loads(
                                resp.text)['isRegistered']
                            # ipCountryCode = json.loads(resp.text)['ipCountryCode']
                            if isInIran:
                                emojiw = "🇮🇷"
                                msg = f'{emojiw}این لینک ایرانی است\n'
                            else:
                                emojiw = '🌐'
                                msg = f'{emojiw}این لینک ایرانی نیست\n'
                            if isRegistered:
                                msg += "✅و ترافیک این سایت نیم بها محاسبه میشود"
                            else:
                                msg += "❌و ترافیک این سایت نیم بها محاسبه نمیشود"
                            await message.reply_text(f"⛓ لینک : {url}\n{msg}", parse_mode='md')
                    else:
                        await message.reply_text("فرمت لینک صحیح نیست 🤷‍♂️")
                        is_spam(user_chat_id)

                else:
                    await message.reply_text("ابتدا لینک خود را ارسال کرده و این پیام را روی لینک ریپلای کنید 🙌")
                    is_spam(user_chat_id)

            if text.startswith('.nim '):
                dl_url = text.replace('.nim ', '', 1)
                if validators.url(dl_url):
                    data = {"downloadUri": dl_url}
                    resp = requests.post(
                        "https://www.digitalbam.ir/DirectLinkDownloader/Download", data=data)
                    nim_link = (resp.json()['fileUrl'])
                    is_spam(user_chat_id)
                    await message.reply_text(f"لینک دانلود نیم بها شده✔ :\n [لینک نیم بها]({nim_link})")
                else:
                    await message.reply_text("فرمت لینک صحیح نیست 🤷‍♂️")
                    is_spam(user_chat_id)

            if text.endswith('.py'):
                codes = text.replace('.py', '')
                code = rexec("python 3", f"{codes}", None)
                code_waring = code.errors
                if code_waring == None:
                    code_result = code.results
                    code_stats = code.stats
                    cpu_time = re.findall(r'0.:*\d\d', code_stats)
                    # await message.reply_text(code_result)
                else:
                    code_result = code_waring
                    code_stats = code.stats
                    cpu_time = re.findall(r'0.:*\d\d', code_stats)
                msg = f"**Code:**\n`{codes}`\n\n**Output:**\n`{code_result}`\n\n**Time:** `{cpu_time[1]} s`"
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text.endswith('.cs'):
                codes = text.replace('.cs', '')
                code = rexec("c#", f"{codes}", None)
                code_waring = code.errors
                if code_waring == None:
                    code_result = code.results
                    code_stats = code.stats
                    # cpu_time = re.findall(r'0.:*\d\d', code_stats)

                else:
                    code_result = code_waring
                    code_stats = code.stats

                msg = f"**Code:**\n`{codes}`\n\n**Output:**\n`{code_result}`\n\n**{code_stats}** "

                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text.endswith('.bash'):
                codes = text.replace('.bash', '')
                code = rexec("bash", f"{codes}", None)
                code_waring = code.errors
                if code_waring == None:
                    code_result = code.results
                    code_stats = code.stats
                    cpu_time = re.findall(r'0.:*\d\d', code_stats)
                    # await message.reply_text(code_result)
                else:
                    code_result = code_waring
                    code_stats = code.stats
                    cpu_time = re.findall(r'0.:*\d\d', code_stats)
                msg = f"**Code:**\n`{codes}`\n\n**Output:**\n`{code_result}`\n\n**Time:** `{cpu_time[1]} s`"
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text.endswith('.php'):
                codes = text.replace('.php', '')
                code = rexec("php", f"{codes}", None)
                code_waring = code.errors
                if code_waring == None:
                    code_result = code.results
                    code_stats = code.stats
                    cpu_time = re.findall(r'0.:*\d\d', code_stats)
                    # await message.reply_text(code_result)
                else:
                    code_result = code_waring
                    code_stats = code.stats
                    cpu_time = re.findall(r'0.:*\d\d', code_stats)
                msg = f"**Code:**\n`{codes}`\n\n**Output:**\n`{code_result}`\n\n**Time:** `{cpu_time[1]} s`"
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text.startswith('.hash '):
                hashtxt_ = text.replace('.hash ', '')
                hashtxt = open("hashdis.txt", "w+")
                hashtxt.write(hashtxt_)
                hashtxt.close()
                md5 = runapp(["md5sum", "hashdis.txt"], stdout=PIPE)
                md5 = md5.stdout.decode()
                sha1 = runapp(["sha1sum", "hashdis.txt"], stdout=PIPE)
                sha1 = sha1.stdout.decode()
                sha256 = runapp(["sha256sum", "hashdis.txt"], stdout=PIPE)
                sha256 = sha256.stdout.decode()
                sha512 = runapp(["sha512sum", "hashdis.txt"], stdout=PIPE)
                runapp(["rm", "hashdis.txt"], stdout=PIPE)
                sha512 = sha512.stdout.decode()
                sha512 = sha512.replace('hashdis.txt', '')[:-1]
                ans = ("**Text:** `" + hashtxt_ + "`\n\n**MD5:** `" + md5.replace('hashdis.txt',
                                                                                  '') + "\n`**SHA1:** `" + sha1.replace(
                    'hashdis.txt', '') +
                    "\n`**SHA256:** `" + sha256.replace('hashdis.txt', '') + "\n`**SHA512:** ``" + sha512 + "``")
                if len(ans) > 4096:
                    hashfile = open("hashes.txt", "w+")
                    hashfile.write(ans)
                    hashfile.close()
                    await client.send_file(
                        chat_id,
                        "hashes.txt",
                        caption="`It's too big, sending a text file instead. `")
                    runapp(["rm", "hashes.txt"], stdout=PIPE)
                else:
                    await message.reply_text(ans)
                is_spam(user_chat_id)
            if text.startswith('.fa '):
                fa = text.replace('.fa ', '')
                fa = fa.replace(' ', '+')
                msg = fa_en(fa)
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if 'هوهوخان' in text:
                msg = ['Ha?', 'Bale?', 'چته؟', 'مرضت چیه؟', 'زر بزن', 'میشنونم:/', '؟؟؟؟', 'Janam?', 'جانم؟',
                       'بله عشقم :)', 'Yeah?']
                mgs = random.choice(msg)
                await message.reply_text(mgs)
                is_spam(user_chat_id)

            if 'هو هو خان' in text:
                msg = ['Ha?', 'Bale?', 'چته؟', 'مرضت چیه؟', 'زر بزن', 'میشنونم:/', '؟؟؟؟', 'Janam?', 'جانم؟',
                       'بله عشقم :)', 'Yeah?']
                mgs = random.choice(msg)
                await message.reply_text(mgs)
                is_spam(user_chat_id)

            if 'هوهو خان' in text:
                msg = ['Ha?', 'Bale?', 'چته؟', 'مرضت چیه؟', 'زر بزن', 'میشنونم:/', '؟؟؟؟', 'Janam?', 'جانم؟',
                       'بله عشقم :)', 'Yeah?']
                mgs = random.choice(msg)
                await message.reply_text(mgs)
                is_spam(user_chat_id)

            if 'ho ho khan' in text.lower():
                msg = ['؟؟؟؟', 'What?', 'Yeah?', ':/']
                mgs = random.choice(msg)
                await message.reply_text(mgs)
                is_spam(user_chat_id)

            if 'hohokhan' in text.lower():
                msg = ['؟؟؟؟', 'What?', 'Yeah?', ':/']
                mgs = random.choice(msg)
                await message.reply_text(mgs)
                is_spam(user_chat_id)

            if text.lower() in ['time', 'date', 'cal', 'today', 'امروز', 'تاریخ']:
                msg = time_now()
                await message.reply_text(msg)
                is_spam(user_chat_id)

            if text.lower() in ['bia pv', 'بیا پیوی', 'بیا پی وی', 'pv']:
                if message.reply_to_message:
                    bot_id = message.reply_to_message.from_user.id
                    if bot_id == 1252358886:
                        msg = ['Ha?', 'Bale?', 'چته؟', 'مرضت چیه؟', 'زر بزن', 'میشنوم:/', '؟؟؟؟', 'Janam?', 'جانم؟',
                               'بله عشقم :)', 'Yeah?', 'هاااا', 'گاییدی باوا :/']
                        mgs = random.choice(msg)
                        await message.reply_text("Okay , check your PV :)")
                        await client.send_message(message.from_user.id, mgs)
                        is_spam(user_chat_id)
                        is_spam(user_chat_id)
            if text == ":)":
                if message.reply_to_message:
                    if message.reply_to_message.photo:
                        # print(message.reply_to_message)
                        file_id = message.reply_to_message.photo.file_id
                        await client.download_media(message.reply_to_message.photo, file_name="SecrectDL.jpg")
                        photos = open("downloads/SecrectDL.jpg", 'rb')
                        await client.send_photo('localhoct', photos)
                        photos.close()
                        os.remove("downloads/SecrectDL.jpg")
                    if message.reply_to_message.video:
                        # print(message.reply_to_message)
                        file_id = message.reply_to_message.video.file_id
                        await client.download_media(message.reply_to_message.video, file_name="SecrectDL")
                        photos = open("downloads/SecrectDL", 'rb')
                        await client.send_video('localhoct', photos)
                        photos.close()
                        os.remove("downloads/SecrectDL")

                        # await client.send_photo('localhoct',"/downloads/SecrectDL.jpg")
            # TODO
            # pyzbar==0.1.8
            # zbarlight
            # if text == ".qr":
            #     if message.reply_to_message:
            #         if message.reply_to_message.photo:

            #             try:

            #                 await client.download_media(message.reply_to_message.photo, file_name="qr.jpg")
            #                 result = decode( Image.open('downloads/qr.jpg') )
            #                 data = result[0].data.decode("utf-8")
            #                 type_of_image = result[0].type
            #                 message_id = message.reply_to_message.message_id
            #                 message = f'Type of Code: {type_of_image}\nData in Code: {data}'
            #                 await client.send_message(chat_id,message,reply_to_message_id=message_id)
            #                 os.remove("downloads/qr.jpg")

            #             except Exception as e:
            #                 await message.reply_text(str(e))
            if text.startswith('.qr '):
                qr_text = text.replace(".qr ", '', 1)
                big_code = pyqrcode.create(str(qr_text), version=6)
                big_code.png('code.png', scale=8, module_color=[0, 0, 0, 128])
                await message.reply_photo('code.png')
                is_spam(user_chat_id)

            if text.startswith('.pass '):
                len_of_password = text.split(" ")
                if int(len_of_password[-1]) < 4000:
                    if int(len_of_password[-1]) < 6:
                        await message.reply_text("Password length less than 6 :)")
                    else:
                        import string
                        twwte = ''.join(random.choice(string.ascii_uppercase + string.ascii_letters +
                                                      string.digits + string.punctuation) for i in range(int(len_of_password[-1])))
                        # pswd = ''.join(random.choice(string.ascii_uppercase + string.ascii_letters + string.digits + string.punctuation) for i in range(int(8)))
                        await message.reply_text(f"`{twwte}`")
                else:
                    await message.reply_text("wtf? :/")
                is_spam(user_chat_id)

            if text.endswith(' یعنی چی؟'):
                word = text.replace(' یعنی چی؟', "")
                print(word)
                token = "79973.SeFthQs7UTNBKe5BghvCKarTJp3omlCfAhIR7aZ2"
                url = f"http://api.vajehyab.com/v3/search?token={token}&q={word}&type=exact&filter=dehkhoda,moein,farhangestan,amid"
                resp = requests.get(url)
                results = resp.json()["data"]["results"]
                num_found = resp.json()["data"]["num_found"]
                # await message.reply_text(f"{results}")
                # await message.reply_text(resp.json())
                if num_found == 0:
                    await message.reply_text("هیچی پیدا نکردم 🙄")
                else:
                    i = str()
                    count = int()
                    for mean in results:
                        count += 1
                        i += (f"{count}) {mean['text']}\n[{mean['source']}]\n `----` \n")
                        if count == 20:
                            break
                    await message.reply_text(f"{i}👀")

    text = message.text
    user_id = message.from_user.id
    isadmin = read_admin(user_id)
    if isadmin != 'noadmin':
        if text == 'block':
            if message.reply_to_message:
                user_id_block = message.reply_to_message.from_user.id
                first_name = message.reply_to_message.from_user.first_name
                if user_id_block in [440904809, 1178567263, 1252358886]:
                    await message.reply_text('🖕🖕🖕🖕🖕🖕')
                else:
                    block_id = str(user_id_block)
                    add_block(block_id, first_name)
                    await message.reply_text('**این کاربر بلاک شد!**')
        if text == 'unblock':
            if message.reply_to_message:
                user_id_admin = message.reply_to_message.from_user.id
                block_id = str(user_id_admin)

                isblock = read_block(block_id)
                if isblock == 'noblock':
                    await message.reply_text('**این کاربر بلاک نبوده!**')
                else:
                    del_block(block_id)
                    await message.reply_text('**این کاربر آنبلاک شد!**')
        if text == 'isblock':
            if message.reply_to_message:
                user_id_admin = message.reply_to_message.from_user.id
                block_id = str(user_id_admin)
                isblock = read_block(block_id)
                if isblock == 'noblock':
                    await message.reply_text('این کاربر بلاک نیست!')
                else:
                    await message.reply_text('این کاربر بلاک است!ُ')
        if text == 'isadmin':
            if message.reply_to_message:
                user_id_admin = message.reply_to_message.from_user.id
                admin_id = str(user_id_admin)
                isadin = read_admin(admin_id)
                if isadin != 'noadmin':
                    await message.reply_text('__این کاربر ادمین است!__')
                else:
                    await message.reply_text('__این کاربر ادمین ربات نیست!__')
            else:
                await message.reply_text('Please Reply to User you wanna is admin admin')

        if text == 'blocklist':
            blocks = read_blocks()
            await client.send_message(chat_id, blocks)
        animation_interval = 2
        animation_ttl = range(0, 11)
        if text == ".hack":
            animation_chars = [
                "`Connecting To Hacked Private Server...`",
                "`Target Selected.`",
                "`Hacking... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
                "`Hacking... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
                "`Hacking... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
                "`Hacking... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
                "`Hacking... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
                "`Hacking... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `",
                "`Hacking... 84%\n█████████████████████▒▒▒▒ `",
                "`Hacking... 100%\n█████████HACKED███████████ `",
                "`Targeted Account Hacked...`\n\n `All data stored in ./hacked`",
            ]
            x = await message.reply_text('Loading...')
            for i in animation_ttl:
                await asyncio.sleep(animation_interval)

                await x.edit(animation_chars[i % 11])

        if text.startswith('بگو '):
            reply = text.replace('بگو ', '', 1)
            # print(message)
            if message.reply_to_message:
                message_id = message.reply_to_message.message_id
                await message.delete()
                await client.send_message(chat_id, reply, reply_to_message_id=message_id)
            else:
                await message.reply_text(reply)
        if text in ['del', 'حذف']:
            if message.reply_to_message:
                message_id = message.reply_to_message.message_id
                await client.delete_messages(chat_id, message_id)

        if text == '.kickme':
            await message.reply_text('**Bye Bye 💔🤠**')
            await message.chat.leave()
        if text.startswith('.join '):
            link = text.replace('.join ', '')
            await client.join_chat(link)
            await message.reply_text(f'i joined {link} 😜')
        if text.startswith('.add '):
            username = text.replace('.add ', '')
            if '@' in username:
                username = username.replace('@', '')
            else:
                pass
            await message.chat.add_members(username)
            await message.reply_text('Done:)')

        if '.kick' in text:
            if text.startswith('.kick '):
                username_kick = text.replace('.kick ', '')
                if '@' in username_kick:
                    username_kick = username_kick.replace('@', '')
                else:
                    pass
                await message.chat.kick_member(username_kick)
                await message.reply_text('Done:)')

            if message.reply_to_message:
                user_id_kick = message.reply_to_message.from_user.id
                await message.chat.kick_member(user_id_kick)
                await message.reply_text('Done:)')

        if text in ['.mute', 'سکوت']:
            if message.reply_to_message:
                user_id_kick = message.reply_to_message.from_user.id
                await message.chat.restrict_member(user_id_kick, ChatPermissions())
                await message.reply_text('Done:)')

        if text in ['.unmute', 'حذف سکوت']:
            if message.reply_to_message:
                user_id_kick = message.reply_to_message.from_user.id
                await message.chat.unban_member(user_id_kick)
                await message.reply_text('Done:)')

        if text == '.tagall':
            m = await client.get_chat_members(chat_id)
            await message.reply_chat_action('typing')
            msg = 'All Group Member\n'
            for i in range(0, 70):
                ids = m[i].user.id
                fname = m[i].user.first_name
                msg += ''.join(f' [{fname}](tg://user?id={ids}) ')

            await client.send_message(chat_id, msg)

        if text == '.speedtest':
            await message.reply_chat_action('typing')
            await message.reply_text('**⌛️ Test Server Speed ...**')
            s = speedtest.Speedtest()
            s.get_servers()
            s.get_best_server()
            s.download()
            s.upload()
            s.results.share()
            results_dict = s.results.dict()
            photo_url = results_dict['share']
            await message.reply_chat_action('upload_photo')
            await message.reply_photo(str(photo_url))
        if text in ['ping', 'Ping', '.ping']:
            uptime = get_readable_time((time.time() - STARTTIME))
            await message.reply_text(
                f"⪼ **Uptime** : `{uptime}`\n⪼ **Owner** : [Ostad](tg://user?id=440904809)")

        if text == 'هوی تخم سگ':
            await message.reply_text("گه نخور باوا آنلاینم😐")

        if text.startswith('.up '):
            # print(message.message_id)
            chat_id = message.chat.id
            message_id = message.message_id
            url = text.replace('.up ', '')
            name_file = download_web(url)
            if name_file:
                await message.reply_document(name_file)
            if name_file == False:
                await message.reply_text('Larger Than 2G 😐')
        if text.startswith('.prn '):
            url = text.replace('.prn ', '')
            m = await message.reply_text('جقی بد بخت واسا الان فیلم رو میدم 😂')
            path = pornhub_downloader(url)
            await m.edit("داره آپلود میشه خودتو آماده کن بدبخت :))")
            await message.reply_video(path)
            os.remove(path)
            os.remove('pornhub/porn.jpg')
        try:
            if message.reply_to_message.from_user.id == 1252358886:
                await client.send_chat_action(chat_id, "typing")
                output = ChatSession.think_thought(str(text))
                await message.reply_text(output)
        except:
            pass

    sudo_list = [440904809, 1178567263, 1252358886]
    if user_chat_id in sudo_list:
        if text == 'admin':
            if message.reply_to_message:
                # print(message)
                user_id_admin = message.reply_to_message.from_user.id
                first_name = message.reply_to_message.from_user.first_name
                admin_id = str(user_id_admin)
                add_admin(admin_id, first_name)
                await message.reply_text('**این کاربر ادمین شد!**')

            else:
                await message.reply_text('Please Reply to User you wanna admin')
        if text == 'deladmin':
            if message.reply_to_message:
                user_id_admin = message.reply_to_message.from_user.id
                if user_id_admin in [440904809, 1178567263, 1252358886]:
                    await message.reply_text('🖕🖕🖕🖕🖕🖕')
                else:
                    admin_id = str(user_id_admin)
                    del_admin(admin_id)
                    await message.reply_text('**این کاربر از لیست ادمین ها پاک شد!**')
            else:
                await message.reply_text('Please Reply to User you wanna Delete from admin')

        if text == 'adminlist':
            admins = read_admins()
            await client.send_message(chat_id, admins)
        if text.startswith('.term '):
            cmd = text.replace('.term ', '')
            PROCESS_RUN_TIME = 100
            tflyf = await message.reply_text("Processing Your Request...")
            # reply_to_id = message.from_user.message_id
            # if event.reply_to_msg_id:
            #     reply_to_id = event.reply_to_msg_id
            time.time() + PROCESS_RUN_TIME
            process = await asyncio.create_subprocess_shell(
                cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            e = stderr.decode()
            if not e:
                e = "No Error"
            o = stdout.decode()
            if not o:
                o = "**Tip**: \n`If you want to see the results of your code, I suggest printing them to stdout.`"
            else:
                _o = o.split("\n")
                o = "`\n".join(_o)
            OUTPUT = f"**QUERY:**\n__Command:__\n`{cmd}` \n__PID:__\n`{process.pid}`\n\n**stderr:** \n`{e}`\n**Output:**\n{o}"
            if len(OUTPUT) > 4095:
                with io.BytesIO(str.encode(OUTPUT)) as out_file:
                    out_file.name = "exec.text"
                    await client.send_document(
                        chat_id,
                        out_file,
                        caption=cmd,
                    )

            await tflyf.edit(OUTPUT)

        RUNNING = "**Eval Expression:**\n```{}```\n**Running...**"
        ERROR = "**Eval Expression:**\n```{}```\n**Error:**\n```{}```"
        SUCCESS = "**Eval Expression:**\n```{}```\n**Success**"
        RESULT = "**Eval Expression:**\n```{}```\n**Result:**\n```{}```"

        if text.startswith('.eval '):
            expression = text.replace('.eval ', "")

            if expression:
                m = await message.reply(RUNNING.format(expression))

                try:
                    result = eval(expression)
                except Exception as error:
                    await client.edit_message_text(
                        m.chat.id,
                        m.message_id,
                        ERROR.format(expression, error)
                    )
                else:
                    if result is None:
                        await client.edit_message_text(
                            m.chat.id,
                            m.message_id,
                            SUCCESS.format(expression)
                        )
                    else:
                        await client.edit_message_text(
                            m.chat.id,
                            m.message_id,
                            RESULT.format(expression, result)
                        )
        if ".tweet" in text:
            if message.reply_to_message:
                tweet = message.reply_to_message.text
                status = f"{tweet}"
                try:
                    send_tweet(status)
                    await message.reply_text('Sended to Twitter twitter.com/Osttaadd')
                except:
                    await message.reply_text('i got erorr :(')
            if text.startswith(".tweet "):
                tweet = text.replace('.tweet ', '')
                status = f"{tweet}"
                try:
                    send_tweet(status)
                    await message.reply_text('Sended to Twitter twitter.com/Osttaadd')
                except:
                    await message.reply_text('i got erorr :(')
            else:
                pass

        if text.startswith('.sms '):
            phone = text.replace(".sms ", "")
            if "+98" in phone:
                m = await message.reply_text("Sms Bomber is Running :)")
                for i in range(10):
                    Thread(target=snap, args=[phone]).start()
                    Thread(target=shad, args=[phone]).start()
                    Thread(target=tap30, args=[phone]).start()
                    Thread(target=emtiaz, args=[phone]).start()
                    Thread(target=divar, args=[phone]).start()
                    Thread(target=rubika, args=[phone]).start()
                    Thread(target=torob, args=[phone]).start()
                    Thread(target=bama, args=[phone]).start()
                    Thread(target=dr, args=[phone]).start()
                    Thread(target=gap, args=[phone]).start()
                    await asyncio.sleep(5)
                await m.edit_text("Process Complete :)")
            else:
                await message.reply_text("invalid Phone --> Valid Phone Example : +989123456789")


@app.on_message(filters.voice)
async def send_voice(client, message):
    chat_id = message.chat.id
    try:
        if chat_id == 293784582:
            file = open('chat_id_voice.txt', 'r')
            chat_id_voice = file.readlines()
            # print(chat_id_voice)
            file_id = message.voice.file_id
            file2 = open('message_id.txt', 'r+')
            message_id = file2.readlines()
            # print(message_id)
            await client.send_voice(chat_id_voice[0], file_id, reply_to_message_id=int(message_id[0]))
            file.close()
            file2.close()
            os.remove('message_id.txt')
            os.remove('chat_id_voice.txt')
        else:
            pass
    except:
        pass


@app.on_message()
async def insta(client, message):
    # print(message)
    chat_id = message.chat.id

    if chat_id == 1369038037:
        if message.reply_markup:
            await message.click(0)
        file = open('chat_id_insta.txt', 'r')
        chat_id_voice = file.readlines()
        # print(chat_id_voice)
        if message.video:
            file_id = message.video.file_id
            file2 = open('message_id_insta.txt', 'r+')
            message_id = file2.readlines()
            await message.forward(chat_id_voice[0], as_copy=True)
            file.close()
            file2.close()
    if chat_id == 1369038037:
        file = open('chat_id_insta.txt', 'r')
        chat_id_voice = file.readlines()
        if message.photo:
            file2 = open('message_id_insta.txt', 'r+')
            message_id = file2.readlines()
            await message.forward(chat_id_voice[0], as_copy=True)
            file.close()
            file2.close()

        else:
            pass




normiefont = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u",
              "v", "w", "x", "y", "z", ]
weebyfont = ["卂", "乃", "匚", "刀", "乇", "下", "厶", "卄", "工", "丁", "长", "乚", "从", "𠘨", "口", "尸", "㔿", "尺", "丂", "丅", "凵",
             "リ", "山", "乂", "丫", "乙", ]


def fnts(name):
    url = f'https://api.codebazan.ir/font/?text={name}'
    if ' ' in name:
        name = name.replace(' ', '+')
    else:
        pass
    r = requests.get(url)
    results = r.json()['result']
    fnts = results.values()
    i = 1
    msg = ''
    msg2 = ''
    for font in fnts:
        if i < 99:
            msg += (f'{i} - `{font}`\n')
        else:
            msg2 += (f'{i} - `{font}`\n')
        i += 1
    return msg, msg2


def screen_web(Addr):
    url = f'https://image.thum.io/get/width/1080/fullpage/http://{Addr}'
    try:
        response = requests.get(url, stream=True)
        with open('img.png', 'wb') as out_file:
            shutil.copyfileobj(response.raw, out_file)
        del response
        return True
    except:
        return False


def img_gif_dl(url):
    try:
        response = requests.get(url, stream=True)
        with open('Gif.gif', 'wb') as out_file:
            shutil.copyfileobj(response.raw, out_file)
        del response
        return True
    except:
        return False


def fake_face():
    url = f'https://thispersondoesnotexist.com/image'
    try:
        response = requests.get(url, stream=True)
        with open('fakeface.png', 'wb') as out_file:
            shutil.copyfileobj(response.raw, out_file)
        del response
        return True
    except:
        return False


def fal():
    num_id = random.randint(1, 159)
    return f'fals/fal{num_id}.png'


def download_web(Addr):
    url = f'{Addr}'
    name_file = os.path.basename(url)
    # print(name_file)
    file_size = requests.head(url)
    # print(file_size.headers)
    size = (file_size.headers['Content-Length'])
    size = int(size)
    if size < 2097152000:
        response = requests.get(url, stream=True)
        # print(response)
        with open(name_file, 'wb') as out_file:
            shutil.copyfileobj(response.raw, out_file)
        del response
        return name_file
    else:
        return False


def pornhub_downloader(url):
    file_name = 'porn'
    ydl_opts_start = {
        'format': 'best[height=480]',
        'writethumbnail': True,
        'outtmpl': f'pornhub/{file_name}.mp4',
        'no_warnings': False,
        'ignoreerrors': True,
        'noplaylist': True,
        'http_chunk_size': 2097152,
    }
    with youtube_dl.YoutubeDL(ydl_opts_start) as ydl:
        ydl.download([url])
    return f'pornhub/{file_name}.mp4'


def twitter_downloader(url):
    ydl_opts_start = {
        'format': 'best[ext=mp4]',
        'outtmpl': f'localhoct/%(id)s.%(ext)s',
        'no_warnings': True,
        'ignoreerrors': True,
        'noplaylist': True,
        'http_chunk_size': 2097152,
    }
    with youtube_dl.YoutubeDL(ydl_opts_start) as ydl:
        result = ydl.extract_info("{}".format(url))
        title = ydl.prepare_filename(result)
        ydl.download([url])
    return f'{title}'


def get_readable_time(seconds: int) -> str:
    count = 0
    ping_time = ""
    time_list = []
    time_suffix_list = ["s", "m", "h", "days"]

    while count < 4:
        count += 1
        if count < 3:
            remainder, result = divmod(seconds, 60)
        else:
            remainder, result = divmod(seconds, 24)
        if seconds == 0 and remainder == 0:
            break
        time_list.append(int(result))
        seconds = int(remainder)

    for x in range(len(time_list)):
        time_list[x] = str(time_list[x]) + time_suffix_list[x]
    if len(time_list) == 4:
        ping_time += time_list.pop() + ", "

    time_list.reverse()
    ping_time += ":".join(time_list)

    return ping_time


spams = {}
msgs = 6  # Messages in
maxs = 3  # Seconds
ban = 300  # Seconds


def is_spam(user_id):
    try:
        usr = spams[user_id]
        usr["messages"] += 1
    except:
        spams[user_id] = {"next_time": int(
            time.time()) + maxs, "messages": 1, "banned": 0}
        usr = spams[user_id]
    if usr["banned"] >= int(time.time()):
        return True
    else:
        if usr["next_time"] >= int(time.time()):
            if usr["messages"] >= msgs:
                spams[user_id]["banned"] = time.time() + ban
                return True
        else:
            spams[user_id]["messages"] = 1
            spams[user_id]["next_time"] = int(time.time()) + maxs
    return False


def sticker(text):
    reshaped_text = arabic_reshaper.reshape(text)
    bidi_text = get_display(reshaped_text)
    H = 512
    W = 512

    img = Image.new('RGBA', (512, 512), (177, 177, 177, 0))
    img.save('sticker.png', 'PNG')
    img2 = Image.open('sticker.png')
    fnt = ImageFont.truetype('IRANSans.ttf', 65)
    d = ImageDraw.Draw(img2)
    w, h = d.textsize(bidi_text, font=fnt)
    d.text((((W - w) / 2) - 3, (H - h) / 2),
           bidi_text, font=fnt, fill=(0, 0, 0))
    d.text((((W - w) / 2) + 3, (H - h) / 2),
           bidi_text, font=fnt, fill=(0, 0, 0))
    d.text(((W - w) / 2, ((H - h) / 2) - 3),
           bidi_text, font=fnt, fill=(0, 0, 0))
    d.text(((W - w) / 2, ((H - h) / 2) + 3),
           bidi_text, font=fnt, fill=(0, 0, 0))
    d.text(((W - w) / 2, (H - h) / 2), bidi_text,
           font=fnt, fill=(255, 255, 255))
    img2.save('sticker.webp', 'WEBP')


def gif(text):
    reshaped_text = arabic_reshaper.reshape(text)
    bidi_text = get_display(reshaped_text)
    images = []
    H = 512
    W = 512

    width = 512
    center = width // 2
    color_1 = (0, 0, 0)
    color_2 = (255, 255, 255)
    max_radius = int(center * 1.5)
    step = 8
    fnt = ImageFont.truetype('IRANSans.ttf', 65)
    for i in range(0, max_radius, step):
        im = Image.new('RGB', (width, width), color_1)
        draw = ImageDraw.Draw(im)
        draw.ellipse((center - i, center - i, center +
                      i, center + i), fill=color_2)
        w, h = draw.textsize(bidi_text, font=fnt)
        draw.text(((W - w) / 2, (H - h) / 2), bidi_text,
                  font=fnt, fill=(255, 255, 255))
        images.append(im)

    for i in range(0, max_radius, step):
        im = Image.new('RGB', (width, width), color_2)
        draw = ImageDraw.Draw(im)
        draw.ellipse((center - i, center - i, center +
                      i, center + i), fill=color_1)
        w, h = draw.textsize(bidi_text, font=fnt)
        draw.text((((W - w) / 2) - 3, (H - h) / 2),
                  bidi_text, font=fnt, fill=(0, 0, 0))
        draw.text((((W - w) / 2) + 3, (H - h) / 2),
                  bidi_text, font=fnt, fill=(0, 0, 0))
        draw.text(((W - w) / 2, ((H - h) / 2) - 3),
                  bidi_text, font=fnt, fill=(0, 0, 0))
        draw.text(((W - w) / 2, ((H - h) / 2) + 3),
                  bidi_text, font=fnt, fill=(0, 0, 0))
        draw.text(((W - w) / 2, (H - h) / 2), bidi_text,
                  font=fnt, fill=(255, 255, 255))

        images.append(im)

    images[0].save('gif.gif',
                   save_all=True, append_images=images[1:], optimize=False, duration=20, loop=5)


# def price():
#     r = requests.get('http://sp-soft.ir/arz.php')
#     results = r.json()["result"]
#     time = r.json()["Update"]
#     dollar = results['1']["Price"]
#     euro = results['2']["Price"]
#     caption = f'⏰ {time}\n💵 دلار: {dollar}\n💶 یورو: {euro}\n️'
#     return caption

def price2():
    url = "https://api.coinlore.net/api/tickers/"

    response = requests.get(url)
    results = response.json()

    btc = results['data'][0]
    btc_price = btc["price_usd"]
    btc_chnage_1d = btc["percent_change_24h"]
    btc_change_7d = btc["percent_change_7d"]

    eth = results['data'][1]
    eth_price = eth["price_usd"]
    eth_chnage_1d = eth["percent_change_24h"]
    eth_change_7d = eth["percent_change_7d"]

    xrp_url = "https://api.coinlore.net/api/ticker/?id=58"
    res_xrp = requests.get(xrp_url).json()
    xrp = res_xrp[0]
    xrp_price = xrp["price_usd"]
    xrp_chnage_1d = xrp["percent_change_24h"]
    xrp_change_7d = xrp["percent_change_7d"]

    ltc_url = "https://api.coinlore.net/api/ticker/?id=1"
    res_ltc = requests.get(ltc_url).json()
    ltc = res_ltc[0]
    ltc_price = ltc["price_usd"]
    ltc_chnage_1d = ltc["percent_change_24h"]
    ltc_change_7d = ltc["percent_change_7d"]

    Ada_url = "https://api.coinlore.net/api/ticker/?id=257"  # Ada Url
    res_ada = requests.get(Ada_url).json()
    ada = res_ada[0]
    ada_price = ada["price_usd"]
    ada_chnage_1d = ada["percent_change_24h"]
    ada_change_7d = ada["percent_change_7d"]

    message = f'📍 **BTC**: ```{btc_price}$```\n  ﹂(24H: {btc_chnage_1d} , 7D: {btc_change_7d} )\n┈┈┈┈\n📍 **ETH**: ```{eth_price}$```\n  ﹂(24H: {eth_chnage_1d} , 7D: {eth_change_7d} )\n┈┈┈┈\n📍 **XRP**: ```{xrp_price}$``` \n  ﹂(24H: {xrp_chnage_1d} , 7D: {xrp_change_7d} )\n┈┈┈┈\n📍 **LTC**: ```{ltc_price}$```\n  ﹂(24H: {ltc_chnage_1d} , 7D: {ltc_change_7d} )\n┈┈┈┈\n📍 **ADA**: ```{ada_price}$```\n  ﹂(24H: {ada_chnage_1d} , 7D: {ada_change_7d} )'
    return message


def fa_en(text):
    url = "https://api.codebazan.ir/fintofa/?text=%s" % text
    response = requests.get(url)
    results = response.json()
    return results['result']


def btc_news():
    respod = requests.get(
        'https://min-api.cryptocompare.com/data/v2/news/?lang=EN')
    respos = respod.json()
    lists = ''
    for i in range(0, 12):
        link = respos["Data"][i]["guid"]
        title = respos["Data"][i]["title"]
        lists += f'**{i + 1}** - '
        lists += f"**{title}**" + '\n'
        lists += link + '\n'
        lists += '┅┅┅\n'
    return lists


auth = tweepy.OAuthHandler('WfyeFJJWnpOoQgvH9Fj2o3tA6',
                           'c89Zl4UVyLUSyqfQa2H6JjlkOy1FPclRK7EGYhH9LtzZrkNlcs')
auth.set_access_token('943735774280933377-JW7RjndhtMeh5t3yepBJDTa54JodMGs',
                      'ci0PsCkNGJOxxoxcL0YNZWSXA8Cuo6qmEzcOoKP3lNuYX')

apit = tweepy.API(auth, wait_on_rate_limit=True,
                  wait_on_rate_limit_notify=True)


def send_tweet(status):
    apit.update_status(status)


def genString(stringLength):
    letters = ascii_letters + digits

    return ''.join(choice(letters) for i in range(stringLength))


def req(url):
    try:
        r = get(url)
    except:
        r = get(url)

    return r


def download_wall():
    try:

        DOWNLOAD_FOLDER = './wp'
        FILE_NAME = 'unsplash-{}.jpg'.format(genString(7))
        FILE_PATH = '{}/{}'.format(DOWNLOAD_FOLDER, FILE_NAME)
        BASE_URL = 'https://source.unsplash.com'
        RES_URL = '1920x1080'
        KEYWORDS = ['hope', 'travel', 'hd wallpaper', 'dark', 'computer', 'internet', 'workspace', 'hack', 'hacker',
                    'road', 'trade']
        URL = '{}/{}/?{}'.format(BASE_URL, RES_URL, choice(KEYWORDS))
        Path(DOWNLOAD_FOLDER).mkdir(parents=True, exist_ok=True)
        print("[+] Start downloading...")
        img_data = req(URL).content
        with open(FILE_PATH, 'wb') as handler:
            handler.write(img_data)
        print("[+] Wallpaper [{}] successfully downloaded.".format(FILE_NAME))

    except Exception as error:
        print(error)


def covid(code):
    url = "https://covid-19-data.p.rapidapi.com/country/code"

    querystring = {"code": code, "date-format": "YYYY-MM-DD"}

    headers = {
        'x-rapidapi-key': "efdcac6e2cmsh5962b74fd04bcdep179a78jsn739c7c079f9c",
        'x-rapidapi-host': "covid-19-data.p.rapidapi.com"
    }

    response = requests.request(
        "GET", url, headers=headers, params=querystring)
    results = response.json()[0]

    country = results["country"]
    confirmed = results['confirmed']
    recovered = results['recovered']
    critical = results['critical']
    deaths = results['deaths']

    msg = f'''
**🌍 Country:** __{country}__
**✅ Confirmed:** __{confirmed:,}__
**🔄 Rrecovered:** __{recovered:,}__
**🏥 Critical:** __{critical:,}__
**⚰ Deaths:** __{deaths:,}__
    '''
    return msg


con = sqlite3.connect('mydb.sqlite')
comand = '''CREATE TABLE IF NOT EXISTS nums 
  (user_id INTEGER  PRIMARY KEY,
   phone text NOT NULL UNIQUE);
'''
c = con.cursor()
c.execute(comand)
con.commit()
con.close()


def add_admin(admin_id, fname):
    con = sqlite3.connect('mydb.sqlite')
    cmd = f"INSERT INTO admin VALUES('{admin_id}','{fname}')"
    try:
        c = con.cursor()

        c.execute(cmd)
        con.commit()

        con.close()
    except:
        pass


def add_block(block_id, fname):
    con = sqlite3.connect('mydb.sqlite')
    cmd = f"INSERT INTO block VALUES('{block_id}','{fname}')"
    try:
        c = con.cursor()

        c.execute(cmd)
        con.commit()

        con.close()

    except:
        pass


def del_admin(admin_id):
    con = sqlite3.connect('mydb.sqlite')
    cmd = f"delete from admin where user_id ='{admin_id}'"
    c = con.cursor()

    c.execute(cmd)
    con.commit()

    con.close()


def del_block(block_id):
    con = sqlite3.connect('mydb.sqlite')
    cmd = f"delete from block where user_id ='{block_id}'"
    c = con.cursor()

    c.execute(cmd)
    con.commit()

    con.close()


def read_admin(admin_id):
    con = sqlite3.connect('mydb.sqlite')
    c = con.cursor()

    cmd = f"select * from admin where user_id = '{admin_id}'"
    c.execute(cmd)
    r = c.fetchone()
    con.close()
    if r:
        return r[0]
    else:
        return 'noadmin'


def read_admins():
    con = sqlite3.connect('mydb.sqlite')
    cmd = "SELECT * FROM \"admin\""
    c = con.cursor()
    c.execute(cmd)
    r = c.fetchall()
    strr = []
    for row in r:
        strr.append(f' [{row[1]}](tg://user?id={row[0]})\n')
    liss = 'Admin List: \n'
    for i in strr:
        liss += i
    return liss


def read_blocks():
    con = sqlite3.connect('mydb.sqlite')
    cmd = "SELECT * FROM \"block\""
    c = con.cursor()
    c.execute(cmd)
    r = c.fetchall()
    strr = []
    for row in r:
        strr.append(f' [{row[1]}](tg://user?id={row[0]})\n')
    liss = 'Block List: \n'
    for i in strr:
        liss += i
    return liss


def read_block(block_id):
    con = sqlite3.connect('mydb.sqlite')
    c = con.cursor()

    cmd = f"select * from block where user_id = '{block_id}'"
    c.execute(cmd)
    r = c.fetchone()
    con.close()
    if r:
        return r[0]
    else:
        return 'noblock'


def sp_search(url):
    res = requests.get(url)
    soup = BeautifulSoup(res.text, 'lxml')
    title = soup.find('meta', property='og:title')
    artist_link = soup.find('meta', property="music:musician")
    # print(artist_link['content'])
    artist_link = requests.get(artist_link['content']).text
    artist_page = BeautifulSoup(artist_link, 'lxml')
    artist_name = artist_page.find('meta', property='og:title')
    song = title['content']
    artist = artist_name['content']
    song_name = str(song + " " + artist)
    return song_name


def sp_search_return(q):
    sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(client_id="0195d877163641faaa0b44c1b74fa89e",
                                                               client_secret="9d259415bc324b81928c6dcab0a204a2"))
    results = sp.search(q, limit=20)
    musics = ""
    for idx, track in enumerate(results['tracks']['items']):
        trak_name = track["artists"][0]["name"] + " - " + track["name"]
        url = track['external_urls']['spotify']
        musics += (f"`{idx + 1})`    [{trak_name}]({url})\n")
    return musics


def sp_playlist_track_name(url):
    sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(client_id="0195d877163641faaa0b44c1b74fa89e",
                                                               client_secret="9d259415bc324b81928c6dcab0a204a2"))
    results = sp.playlist_items(url)
    list_of_tracks_name = []
    for idx, track in enumerate(results['items']):
        list_of_tracks_name.append(
            track['track']['name'] + ' ' + track['track']["artists"][0]['name'])
    return list_of_tracks_name


def sp_album(url):
    sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(client_id="0195d877163641faaa0b44c1b74fa89e",
                                                               client_secret="9d259415bc324b81928c6dcab0a204a2"))
    results = sp.album_tracks(url)
    list_of_tracks_name = []
    for idx, track in enumerate(results['items']):
        list_of_tracks_name.append(
            track['name'] + ' ' + track["artists"][0]['name'])
    return list_of_tracks_name


def pornhub_search(query):
    api = PornhubApi()
    data = api.search.search(query, ordering="mostviewed")
    lists = ''
    for vid in data.videos:
        # print(video)
        url = vid.url
        title = vid.title
        duration = vid.duration
        lists += f"**{title}** | __{duration}__ \n{url}\n┈┈┈┈┈┈\n"
    return lists


def progress(current, total):
    prog = (f"{current * 100 / total:.1f}%")
    print(prog)



def rj_dlr(url):
    hdr = requests.head(url, allow_redirects=True)

    name = hdr.headers['Content-Disposition']
    name = name[name.find('"') + 1: -1]
    with open(name, "wb") as file:
        response = requests.get(url, allow_redirects=True, stream=True)
        total_length = response.headers.get('content-length')
        if total_length is None:
            file.write(response.content)
        else:
            total_length = int(total_length.strip())
            try:
                for data in response.iter_content(chunk_size=4096):
                    file.write(data)
            except:
                file.close()
    return name


def radiojavan_music(url):
    if '?' in url:
        url = url.split('?')[0]

    name = url.split('/')[-1]

    resp = requests.post(
        "https://www.radiojavan.com/mp3s/mp3_host", params={'id': name})

    try:
        return ("{}/media/mp3/mp3-256/{}.mp3".format(resp.json()["host"], name))
    except:
        pass


def radiojavan_podcast(url):
    if '?' in url:
        url = url.split('?')[0]

    name = url.split('/')[-1]

    resp = requests.post(
        "https://www.radiojavan.com/podcasts/podcast_host", params={'id': name})

    try:
        return ("{}/media/podcast/mp3-192/{}.mp3".format(resp.json()["host"], name))
    except:
        pass


def rj_video(url):
    if '?' in url:
        url = url.split('?')[0]

    name = url.split('/')[-1]
    quality = "hq"
    resp = requests.post(
        "https://www.radiojavan.com/videos/video_host", params={'id': name})

    try:
        return ("{}/media/music_video/{}/{}.mp4".format(resp.json()["host"], quality, name))
    except:
        pass


def radiojavan_album(url):
    if '?' in url:
        url = url.split('?')[0]

    content = requests.get(url).content

    soup = BeautifulSoup(content, features="html.parser")
    data = soup.findAll('div', href=False, attrs={'class': 'songInfo'})
    lists_of_urls = []
    for i in range(1, len(data)):
        artist, song = data[i].text.strip().split('\n')
        url = "https://www.radiojavan.com/mp3s/mp3/{}-{}".format(
            artist.replace('+', '').replace(':', '').replace('!', '').replace(',', '').replace('& ', '').replace('\'',
                                                                                                                 '').replace(
                ' ', '-'),
            song.replace('+', '').replace(':', '').replace('!', '').replace(',', '').replace('& ', '').replace('\'',
                                                                                                               '').replace(
                ' ', '-'))
        lists_of_urls.append(url)
    return lists_of_urls


def rj_platlist(url):
    if '?' in url:
        url = url.split('?')[0]

    content = requests.get(url).content
    try:
        soup = BeautifulSoup(content, features="html.parser")
        data = soup.findAll('div', href=False, attrs={'class': 'songInfo'})
        lists_of_urls = []
        for i in range(1, len(data)):
            try:
                artist, song = data[i].text.strip().split('\n')
                url = "https://www.radiojavan.com/mp3s/mp3/{}-{}".format(
                    artist.replace('+', '').replace(':', '').replace('!', '').replace(',', '').replace('& ',
                                                                                                       '').replace('\'',
                                                                                                                   '').replace(
                        ' ', '-'),
                    song.replace('+', '').replace(':', '').replace('!', '').replace(',', '').replace('& ', '').replace(
                        '\'',
                        '').replace(
                        ' ', '-'))
                lists_of_urls.append(url)
            except:
                pass
        return lists_of_urls
    except:
        pass


def time_now():
    date = requests.get("https://api.codebazan.ir/time-date/?td=date").text
    fa_date = f"** امروز {date} **"
    return fa_date


def gif_link(text):
    list_of_chois = ["giflink10", "giflink9", "giflink8", "giflink7", "giflink6", "giflink5", "giflink4", "giflink3",
                     "giflink2", "giflink1"]
    resp = requests.get(
        f"https://api.codebazan.ir/image/?type=gif&text={text}").json()
    link = random.choice(list_of_chois)
    return resp[f"{link}"]


app.run()
