animation_interval = 2
animation_ttl = range(0, 11)
if text == ".hack":
    animation_chars = [
        "س",
        "سا",
        "سال",
        "سال ن",
        "سال نو",
        "سال نو م",
        "سال نو مب",
        "سال نو مبا",
        "سال نو مبار",
        "سال نو مبارک",
        "❤️ سال نو مبارک ❤️",
        "سال نو مبارک",
        "🍃❤️ سال نو مبارک ❤️🍃",
        "🍃 سال نو مبارک 🍃",
        "🌈 سال نو مبارک 🌈",
        "❤️🍃🌈 سال نو مبارک ❤️🍃🌈",

    ]
    x = await message.reply_text('Loading...')
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)

        await x.edit(animation_chars[i % 11])إ
