STARTTIME = 1610865649.8820722

API_ID = 1691381
API_HASH = "a4b862a161f7a320d5524730bbf51bf2" 
SESSION_NAME = "sefl-v-02"


HELP_MESSGAE =  '''
🤖 Ho Ho Khan Commands Help:

__✅ You Can Send Instagram Post Link or Youtube Video Link For Download Without Commands__
__✅ Twitter Downloader Added (Send twitter Video Link) __
__✅ Instagram Profile photo and story Downloader Added (Send Profile Like : https://instagram.com/1yasin8) __
__✅ Spotify Track , PlayList And Album Downloader Added (Send Link of track Like: https://open.spotify.com/track/7jBRnK8cdFsqaTGoZIH5dd?si=B9AlwG1oQM6vl-Nm6kL-Iw) __
__✅ RadioJavan.com Music , playlist , album ,video and podcast Downloader Added (Send Link Like: https://www.radiojavan.com/mp3s/mp3/Sogand-Tehran )__

**🛠 Command:**
 ﹂ .music [Music Name or Lyrics (any Language) ]
**💬 Description:**
 ﹂Send Music :)
**⌨️ Example:**
 ﹂ .music Dance Monkey

**🛠 Command:**
 ﹂ .yt [Video title]
**💬 Description:**
 ﹂Search on YouTube
**⌨️ Example:**
 ﹂ .yt Dance Monkey

**🛠 Command:**
 ﹂ .spt [Music Name or Lyrics (any Language) ]
**💬 Description:**
 ﹂Search on Spotify
**⌨️ Example:**
 ﹂ .spt Dance Monkey

**🛠 Command:**
 ﹂ .pi [instagram account]
**💬 Description:**
 ﹂ "This Method Not Work Please Send Instagram Profile Link I'll Download Profile and if the page isn't private I'll Send Stories too :)"
**⌨️ Example:**
 ﹂Send Profile Like : https://Instagram.com/1yasin8

**🛠 Command:**
 ﹂ .tts [Your Text(Persian or English)]
**💬 Description:**
 ﹂Convert Text to Speech
**⌨️ Example:**
 ﹂ .tts Hi This is Example

**🛠 Command:**
 ﹂Dice or .dice or تاس
**💬 Description:**
 ﹂SEND Dice

**🛠 Command:**
 ﹂Dart or .dart or دارت
**💬 Description:**
 ﹂SEND Dart

**🛠 Command:**
 ﹂ .bb or bb or Bb or بسکتبال or توپ
**💬 Description:**
 ﹂SEND BasketBall

**🛠 Command:**
 ﹂ .photo or استیکر به عکس
**💬 Description:**
 ﹂Reply to sticker and it's Converted to Photo

**🛠 Command:**
 ﹂ .sticker or .stik or عکس به استیکر
**💬 Description:**
 ﹂Reply to Photo and it's Converted to Sticker

**🛠 Command:**
 ﹂ .wall
**💬 Description:**
 ﹂Send Random WallPaper

**🛠 Command:**
 ﹂ .price
**💬 Description:**
 ﹂Send LIVE Bitcoin Price

**🛠 Command:**
 ﹂ .news
**💬 Description:**
 ﹂Send Latest Bitcoin NEWS

**🛠 Command:**
 ﹂ .jok or جک
**💬 Description:**
 ﹂Send jok

**🛠 Command:**
 ﹂ .hdis or حدیث
**💬 Description:**
 ﹂Send Hadis :)))

**🛠 Command:**
 ﹂ .dnt or دانستنی
**💬 Description:**
 ﹂Send Danestani :)))

**🛠 Command:**
 ﹂ .dialog or دیالوگ
**💬 Description:**
 ﹂Send Dialog :)))

**🛠 Command:**
 ﹂ .covid [Country Code]
**💬 Description:**
 ﹂CoronaVirus Report
**⌨️ Example:**
 ﹂ .covid ir

**🛠 Command:**
 ﹂ .scr [Web addres ]
**💬 Description:**
 ﹂Send ScreenShot of webpage
**⌨️ Example:**
 ﹂ .scr google.com

**🛠 Command:**
 ﹂ .st [text]
**💬 Description:**
 ﹂Convert Text to Sticker
**⌨️ Example:**
 ﹂ .st Hi :) 

**🛠 Command:**
 ﹂ .pass [Password length]
**💬 Description:**
 ﹂Genrate Password
**⌨️ Example:**
 ﹂ .pass 8

**🛠 Command:**
 ﹂ .gif [text]
 ﹂ .giff [text]
**💬 Description:**
 ﹂Convert Text to GIF
**⌨ Example:**
 ﹂ .gif Hi :) 
 ﹂ .giff Hi :) 

**🛠 Command:**
 ﹂ .fnt [text]
**💬 Description:**
 ﹂something intersting :) try it
**⌨ Example:**
 ﹂ .fnt ostad 

**🛠 Command:**
 ﹂ .fake
**💬 Description:**
 ﹂Generate Fake Information

**🛠 Command:**
 ﹂ .fakeface
**💬 Description:**
 ﹂Generate Random Fake Face Photo

**🛠 Command:**
 ﹂ .tr LanguageCode as reply to a message
 ﹂ .tr LangaugeCode | text to translate
**💬 Description:**
 ﹂translate 
**⌨️ Example:**
 ﹂ .tr fa | Hi  
 --------------
💻 Programmer : [𝐎𝐒𝐓𝐀𝐃](tg://user?id=440904809)
'''

